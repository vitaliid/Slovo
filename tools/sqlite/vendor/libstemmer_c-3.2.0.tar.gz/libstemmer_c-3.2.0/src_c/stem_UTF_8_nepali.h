/* Generated from nepali.sbl by Snowball 3.2.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

struct SN_env;

#define nepali_UTF_8_create_env SN_new_env_no_vars
#define nepali_UTF_8_close_env SN_delete_env

extern int nepali_UTF_8_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
