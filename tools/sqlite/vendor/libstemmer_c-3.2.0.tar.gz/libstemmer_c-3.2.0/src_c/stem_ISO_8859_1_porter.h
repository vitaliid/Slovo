/* Generated from porter.sbl by Snowball 3.2.0 - https://snowballstem.org/ */

#ifdef __cplusplus
extern "C" {
#endif

struct SN_env;

#define porter_ISO_8859_1_create_env SN_new_env_no_vars
#define porter_ISO_8859_1_close_env SN_delete_env

extern int porter_ISO_8859_1_stem(struct SN_env * z);

#ifdef __cplusplus
}
#endif
